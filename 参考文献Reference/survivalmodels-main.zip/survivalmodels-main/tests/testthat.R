library(testthat)
library(survivalmodels)

test_check("survivalmodels")
