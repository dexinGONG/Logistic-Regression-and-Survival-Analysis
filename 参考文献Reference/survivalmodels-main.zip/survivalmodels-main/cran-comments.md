I'm submitting again to clear the codecov link NOTE.

## Downstream dependencies

None.

## Test Results

No ERRORs,  WARNINGs or NOTEs.

## Test environments

* x86_64-apple-darwin17.6 (64-bit), macOS Catalina 10.15.3, R 4.0.0
* Microsoft Windows Server 2019, R Release
* Microsoft Windows Server 2019, R Old Release
* Microsoft Windows Server 2019, R Devel
* Mac OS X, R Release
* Ubuntu, R Release
