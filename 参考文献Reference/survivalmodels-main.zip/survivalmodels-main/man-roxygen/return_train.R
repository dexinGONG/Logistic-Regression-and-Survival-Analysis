#' @return An object of class `survivalmodel`.
